

<div class="header-flag-wrap">
                
    
    <?php 
    
    // Use shortcode in a PHP file (outside the post editor).
        echo do_shortcode( ' [gf_featured image="LargeFlag"] ' );
    
    ?>
    
</div>
