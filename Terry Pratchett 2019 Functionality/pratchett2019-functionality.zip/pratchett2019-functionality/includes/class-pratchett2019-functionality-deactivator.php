<?php

/**
 * Fired during plugin deactivation
 *
 * @link       http://example.com
 * @since      1.0.0
 *
 * @package    Pratchett2019_Functionality
 * @subpackage Pratchett2019_Functionality/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Pratchett2019_Functionality
 * @subpackage Pratchett2019_Functionality/includes
 * @author     Your Name <email@example.com>
 */
class Pratchett2019_Functionality_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
